#!/bin/sh
## Set the job name
#PBS -N genomewcatgtfs
#PBS -l nodes=1:ppn=4,vmem=300gb
# Run my job

mkdir /scratch/sf040090/UCSC-hg38_rpandtxs-150overhang

/home/sf040090/software/STAR-2.5.3a/bin/Linux_x86_64/STAR --runThreadN 11 \
--runMode genomeGenerate \
--genomeDir /scratch/sf040090/UCSC-hg38_rpandtxs-150overhang \
--genomeFastaFiles  /home/sf040090/Li-2017-hFGC/genomefiles/UCSChg38.fa \
--sjdbGTFfile /home/sf040090/Li-2017-hFGC/genomefiles/UCSChg38-rpandtxs.gtf \
--sjdbOverhang 149 \
--limitGenomeGenerateRAM 150000000000 \

mv /scratch/sf040090/UCSC-hg38_rpandtxs-150overhang /home/sf040090/

echo "genomewcatgtfs finished"

# error Fatal LIMIT error: the number of junctions to be inserted on the fly =5892406 is larger than the limitSjdbInsertNsj=1000000
# so these parameters worked, but need to add that other command back in.
# also got it to work on a 4 thread, 200gb ram job, so not going to request 300 in future