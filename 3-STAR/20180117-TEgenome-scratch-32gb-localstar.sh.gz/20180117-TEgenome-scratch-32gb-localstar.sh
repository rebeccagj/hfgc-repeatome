#!/bin/sh
## Set the job name
#PBS -N TEgenomegenscratch4
#PBS -l nodes=1:ppn=12,vmem=40gb
# Run my job

mkdir /scratch/sf040090/ref-hg38_91_TE-150overhang4

/home/sf040090/software/STAR-2.5.3a/bin/Linux_x86_64/STAR --runThreadN 11 \
--runMode genomeGenerate \
--genomeDir /scratch/sf040090/ref-hg38_91_TE-150overhang4 \
--genomeFastaFiles  /home/sf040090/Li-2017-hFGC/GRCh38_r91_unmasked.fa \
--sjdbGTFfile /home/sf040090/Li-2017-hFGC/hg38.fa.gtf \
--sjdbOverhang 149 \
--limitGenomeGenerateRAM 32000000000

# this finally had the right amount of RAM, but since my gtf was from UCSC
# and my fa are from ensembl, I get the following error:

# Fatal INPUT FILE error, no valid exon lines in the GTF file: 
# /home/sf040090/Li-2017-hFGC/hg38.fa.gtf
# Solution: check the formatting of the GTF file. 
# Most likely cause is the difference in chromosome naming between GTF and FASTA file.
# See TEgenomegenscratch4.?986207 files