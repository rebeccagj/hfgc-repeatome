#!/bin/sh
## Set the job name
#PBS -N gnmcatgtfs1t
#PBS -l nodes=1:ppn=1,vmem=160gb
# Run my job

mkdir /scratch/sf040090/UCSC-hg38_rpandtxs-150overhang

/home/sf040090/software/STAR-2.5.3a/bin/Linux_x86_64/STAR --runThreadN 1 \
--runMode genomeGenerate \
--genomeDir /scratch/sf040090/UCSC-hg38_rpandtxs-150overhang \
--genomeFastaFiles  /home/sf040090/Li-2017-hFGC/genomefiles/UCSChg38.fa \
--sjdbGTFfile /home/sf040090/Li-2017-hFGC/genomefiles/UCSChg38-rpandtxs.gtf \
--sjdbOverhang 149 \
--limitGenomeGenerateRAMz150000000000 \
--limitSjdbInsertNsj 6000000

mv /scratch/sf040090/UCSC-hg38_rpandtxs-150overhang /home/sf040090/

echo "gnmcatgtfs1t finished"

# various iterations were tried:
# 4 thread, 160 gb with limitSjdbInsertNsj, threw a RAM error
# 4 thread, 300 gb without limitSjdbInsertNsj, threw the fatal limit error below; i never reran because the next job i tried worked

# due to some other forum troubleshooting, I tried 1 thread
# 1 thread, 160 gb without limitSjdbInsertNsj, threw a limitSjdbInsertNsj error
# "Fatal LIMIT error: the number of junctions to be inserted on the fly =5892406 is larger than the limitSjdbInsertNsj=1000000"

# 1 thread, 160 gb with limitSjdbInsertNsj set to 6000000 worked
# i think my limitGenomeGenerateRAM parameter was reset to 32gb by star based on the Log.out
# from 20180201-gnmcatgtf1tLog.out:
# Feb 02 18:04:33 ..... finished successfully DONE: Genome generation, EXITING
