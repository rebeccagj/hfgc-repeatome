#!/bin/sh
## Set the job name
#PBS -N TEgenomegen5
#PBS -l nodes=1:ppn=12,vmem=40gb
# Run my job

mkdir /scratch/sf040090/UCSC-hg38_TE-150overhang

/home/sf040090/software/STAR-2.5.3a/bin/Linux_x86_64/STAR --runThreadN 11 \
--runMode genomeGenerate \
--genomeDir /scratch/sf040090/UCSC-hg38_TE-150overhang \
--genomeFastaFiles  /home/sf040090/Li-2017-hFGC/UCSChg38.fa \
--sjdbGTFfile /home/sf040090/Li-2017-hFGC/hg38.fa.gtf \
--sjdbOverhang 149 \
--limitGenomeGenerateRAM 32000000000

echo finally

mv /scratch/sf040090/UCSC-hg38_TE-150overhang /home/sf040090/Li-2017-hFGC

# getting closer. See log to see how far I got, and also now I need to add a 
# --limitSjdbInsertNsj parameter