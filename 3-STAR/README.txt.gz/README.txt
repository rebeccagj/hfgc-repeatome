explains the files used for generating genomes 

unique-reads: transcriptome, unique alignment in the genome
multi-reads: transposonome, repeats that map to multiple loci with equal quality

ensemblGRCh38_r91_unmasked.fa	- unmasked, all caps whole genome transcript fasta from ensembl
hg38.2bit	- whole genome transcript; soft masked 2bit (repeats in lower case, non-repeats in upper case) from UCSC
rep-hg38repeats.2bit	- made from giri repbase; lower caps, one representative copy of each repeat
rep-hg38repeats.fa	- from giri repbase 2bit file; lower caps, one representative copy of each repeat
rep-hg38repeats-unmasked.fa - made from giri repbase 2bit file; unmasked, all caps fasta containing one copy of each repeat
UCSChg38.fa	- unmasked, all caps whole genome transcript fasta from UCSC
UCSChg38-repeats.gtf	- annotated multi-reads repeats from repeatmasker; generated as hg38.fa.gtf from Ping Ye
UCSChg38-rpandtxs.gtf	- concatenated A) UCSChg38-transcriptome.gtf [unique-reads generated from UCSC] and b) UCSChg38-repeats.gtf [annotated multi-reads repeats from repeatmasker]
UCSChg38-transcriptome.gtf	- annotated unique-reads generated from UCSC [Mammal > Human > Dec. 2013 GRCh38/hg38 > Genes and Gene Predications > GENCODE v24 > knownGene > genome > output: GTF] (notes here https://www.biostars.org/p/174331/)