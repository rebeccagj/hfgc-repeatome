#!/bin/sh
## Set the job name
#PBS -N TEgenomegenscratch
#PBS -l nodes=1:ppn=11,vmem=32gb
# Run my job

mkdir /scratch/sf040090/ref-hg38_91_TE-150overhang

module load CBC 
module load star

STAR --runThreadN 11 \
--runMode genomeGenerate \
--genomeDir /scratch/sf040090/ref-hg38_91_TE-150overhang \
--genomeFastaFiles  /home/sf040090/Li-2017-hFGC/GRCh38_r91_unmasked.fa \
--sjdbGTFfile /home/sf040090/Li-2017-hFGC/hg38.fa.gtf \
--sjdbOverhang 149 \
--limitGenomeGenerateRAM 31000000000

mv /scratch/sf040090/ref-hg38_91_TE-150overhang /home/sf040090