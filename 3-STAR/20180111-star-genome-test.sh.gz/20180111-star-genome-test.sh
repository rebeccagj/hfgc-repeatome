#!/bin/sh
## Set the job name
#PBS -N rgj-genomegen
#PBS -l nodes=1:ppn=11,vmem=32gb
# Run my job

mkdir /scratch/sf040090/starref-hg38_79
cd /scratch/sf040090/starref-hg38_79

module load CBC
module load star

STAR --runMode genomeGenerate --genomeDir /home/sf040090/test/ref/trialgenomeDir --genomeFastaFiles  /home/sf040090/test/ref/GRCh38_r79.all.fa --sjdbGTFfile /home/sf040090/test/ref/Homo_sapiens.GRCh38.79.gtf --sjdbOverhang 100 --runThreadN 1 --limitGenomeGenerateRAM 31000000000

mv /scratch/sf040090/starref-hg38_79 /home/sf040090