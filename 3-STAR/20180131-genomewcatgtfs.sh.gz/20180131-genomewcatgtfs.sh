#!/bin/sh
## Set the job name
#PBS -N genomewcatgtfs
#PBS -l nodes=1:ppn=12,vmem=160gb
# Run my job

mkdir /scratch/sf040090/UCSC-hg38_rpandtxs-150overhang

/home/sf040090/software/STAR-2.5.3a/bin/Linux_x86_64/STAR --runThreadN 11 \
--runMode genomeGenerate \
--genomeDir /scratch/sf040090/UCSC-hg38_rpandtxs-150overhang \
--genomeFastaFiles  /home/sf040090/Li-2017-hFGC/genomefiles/UCSChg38.fa \
--sjdbGTFfile /home/sf040090/Li-2017-hFGC/genomefiles/UCSChg38-rpandtxs.gtf \
--sjdbOverhang 149 \
--limitGenomeGenerateRAM 150000000000 \
--limitSjdbInsertNsj 60000000

mv /scratch/sf040090/UCSC-hg38_rpandtxs-150overhang /home/sf040090/

echo "genomewcatgtfs finished"

# error message ran out of ram? redoing with limiting threads to 4 based on some
# troubleshooting i found on the forums