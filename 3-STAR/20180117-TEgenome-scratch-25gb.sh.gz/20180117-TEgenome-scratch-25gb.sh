#!/bin/sh
## Set the job name
#PBS -N TEgenomegenscratch
#PBS -l nodes=1:ppn=11,vmem=32gb
# Run my job

mkdir /scratch/sf040090/ref-hg38_91_TE-150overhang2

module load CBC 
module load star

STAR --runThreadN 11 \
--runMode genomeGenerate \
--genomeDir /scratch/sf040090/ref-hg38_91_TE-150overhang2 \
--genomeFastaFiles  /home/sf040090/Li-2017-hFGC/GRCh38_r91_unmasked.fa \
--sjdbGTFfile /home/sf040090/Li-2017-hFGC/hg38.fa.gtf \
--sjdbOverhang 149 \
--limitGenomeGenerateRAM 25000000000

# our friend Alex told me to change my RAM limit from 31gb to 25gb and
# for some reason it works. ¯\_(ツ)_/¯ 

mv /scratch/sf040090/ref-hg38_91_TE-150overhang2 /home/sf040090