#!/bin/sh
## Set the job name
#PBS -N TEgenomegen8
#PBS -l nodes=1:ppn=12,vmem=160gb
# Run my job

mkdir /scratch/sf040090/UCSC-hg38_1repcp_TE-150overhang

/home/sf040090/software/STAR-2.5.3a/bin/Linux_x86_64/STAR --runThreadN 11 \
--runMode genomeGenerate \
--genomeDir /scratch/sf040090/UCSC-hg38_1repcp_TE-150overhang \
--genomeFastaFiles  /home/sf040090/Li-2017-hFGC/genomefiles/rep-hg38repeats-unmasked.fa \
--sjdbGTFfile /home/sf040090/Li-2017-hFGC/hg38.fa.gtf \
--sjdbOverhang 149 \
--limitGenomeGenerateRAM 150000000000 \
--limitSjdbInsertNsj 6000000

mv /scratch/sf040090/UCSC-hg38_1repcp_TE-150overhang /home/sf040090/Li-2017-hFGC

echo TEgenomegen8 is done